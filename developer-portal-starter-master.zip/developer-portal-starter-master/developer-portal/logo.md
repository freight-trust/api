# Change your logo

## Add your logo file

Add your logo file.
If you want to overwrite the existing logo, it's at `images/logo.png`.

## Adjust your siteConfig

The `siteConfig.yaml` has a definition of the path to the header icon.
```yaml
headerIcon: ./images/logo.png
```

## Adjust favicon.png

You can overwrite the `favicon.png` file with yours as well.
