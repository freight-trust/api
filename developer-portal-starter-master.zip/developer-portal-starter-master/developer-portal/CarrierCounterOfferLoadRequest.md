# api_client.model.CarrierCounterOfferLoadRequest

## Load the model package
```dart
import 'package:api_client/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**carrierQuoteRequestId** | **String** |  | [optional] 
**lineItems** | [**List&lt;ShipmentFeeServiceModel&gt;**](ShipmentFeeServiceModel.md) |  | [optional] [default to []]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


